import os
import sqlite3
from datetime import datetime, date
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from starlette.status import HTTP_401_UNAUTHORIZED
import secrets

ROOT = Path(__file__).parent
DB_PATH = Path(os.getenv("DATABASE_PATH", ROOT / "lara_sport_fit.db"))
ADMIN_USER = os.getenv("ADMIN_USER", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "")
security = HTTPBasic()

app = FastAPI(title="LARA SPORT FIT booking API", version="1.0.0")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con

def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS sessions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          class_name TEXT NOT NULL,
          coach TEXT NOT NULL DEFAULT 'Уточняется',
          starts_at TEXT NOT NULL,
          capacity INTEGER NOT NULL DEFAULT 8 CHECK(capacity > 0),
          active INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS bookings (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          session_id INTEGER NOT NULL REFERENCES sessions(id),
          client_name TEXT NOT NULL,
          phone TEXT NOT NULL,
          created_at TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'Новая',
          UNIQUE(session_id, phone)
        );
        CREATE INDEX IF NOT EXISTS idx_sessions_starts ON sessions(starts_at);
        """)
init_db()

def require_admin(credentials: HTTPBasicCredentials = Depends(security)):
    ok_user = secrets.compare_digest(credentials.username, ADMIN_USER)
    ok_pass = bool(ADMIN_PASSWORD) and secrets.compare_digest(credentials.password, ADMIN_PASSWORD)
    if not (ok_user and ok_pass):
        raise HTTPException(status_code=HTTP_401_UNAUTHORIZED, detail="Неверный логин или пароль",
                            headers={"WWW-Authenticate": "Basic"})
    return credentials.username

@app.get("/", response_class=HTMLResponse)
def home():
    return FileResponse(ROOT / "static" / "index.html")

@app.get("/admin", response_class=HTMLResponse)
def admin_page():
    return FileResponse(ROOT / "static" / "admin.html")

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "LARA SPORT FIT"}

@app.get("/api/sessions")
def list_sessions(from_date: Optional[str] = None, to_date: Optional[str] = None):
    query = """SELECT s.id, s.class_name, s.coach, s.starts_at, s.capacity,
               (SELECT COUNT(*) FROM bookings b WHERE b.session_id=s.id AND b.status != 'Отменена') AS booked
               FROM sessions s WHERE s.active=1"""
    params = []
    if from_date:
        query += " AND date(s.starts_at) >= date(?)"; params.append(from_date)
    if to_date:
        query += " AND date(s.starts_at) <= date(?)"; params.append(to_date)
    query += " ORDER BY s.starts_at LIMIT 200"
    with db() as con:
        rows = con.execute(query, params).fetchall()
    result = []
    for r in rows:
        item = dict(r)
        item["available"] = max(0, item["capacity"] - item["booked"])
        result.append(item)
    return result

@app.post("/api/bookings")
async def create_booking(request: Request):
    data = await request.json()
    name = str(data.get("name", "")).strip()
    phone = str(data.get("phone", "")).strip()
    session_id = data.get("session_id")
    if not name or len(name) > 100 or not phone or len(phone) > 30:
        raise HTTPException(400, "Укажи имя и корректный номер телефона")
    try:
        session_id = int(session_id)
    except (TypeError, ValueError):
        raise HTTPException(400, "Выбери тренировку")
    with db() as con:
        s = con.execute("SELECT * FROM sessions WHERE id=? AND active=1", (session_id,)).fetchone()
        if not s:
            raise HTTPException(404, "Это занятие больше недоступно")
        if datetime.fromisoformat(s["starts_at"]) <= datetime.now():
            raise HTTPException(400, "Нельзя записаться на прошедшее занятие")
        booked = con.execute("SELECT COUNT(*) n FROM bookings WHERE session_id=? AND status!='Отменена'", (session_id,)).fetchone()["n"]
        if booked >= s["capacity"]:
            raise HTTPException(409, "Свободных мест на это занятие уже нет")
        try:
            cur = con.execute("""INSERT INTO bookings(session_id,client_name,phone,created_at)
                                 VALUES(?,?,?,?)""",
                              (session_id, name, phone, datetime.now().isoformat(timespec="seconds")))
        except sqlite3.IntegrityError:
            raise HTTPException(409, "Этот номер уже записан на выбранное занятие")
        return {"ok": True, "booking_id": cur.lastrowid, "message": "Заявка принята. Студия свяжется для подтверждения."}

@app.get("/api/admin/bookings")
def admin_bookings(_: str = Depends(require_admin)):
    with db() as con:
        rows = con.execute("""SELECT b.id,b.client_name,b.phone,b.created_at,b.status,
                              s.class_name,s.coach,s.starts_at
                              FROM bookings b JOIN sessions s ON s.id=b.session_id
                              ORDER BY s.starts_at DESC,b.created_at DESC LIMIT 500""").fetchall()
    return [dict(r) for r in rows]

@app.post("/api/admin/sessions")
async def admin_create_session(request: Request, _: str = Depends(require_admin)):
    d = await request.json()
    name = str(d.get("class_name","")).strip()
    coach = str(d.get("coach","Уточняется")).strip() or "Уточняется"
    starts = str(d.get("starts_at","")).strip()
    try:
        parsed = datetime.fromisoformat(starts)
        capacity = int(d.get("capacity",8))
        if capacity < 1 or capacity > 100:
            raise ValueError()
    except Exception:
        raise HTTPException(400, "Проверь дату, время и количество мест")
    if name not in ("Джампинг","Фитнес","Нутрициология"):
        raise HTTPException(400, "Выбери направление из списка")
    with db() as con:
        cur = con.execute("INSERT INTO sessions(class_name,coach,starts_at,capacity) VALUES(?,?,?,?)",
                          (name,coach,parsed.isoformat(timespec="minutes"),capacity))
        return {"ok":True,"id":cur.lastrowid}

@app.patch("/api/admin/bookings/{booking_id}")
async def admin_update_booking(booking_id: int, request: Request, _: str = Depends(require_admin)):
    d = await request.json()
    status = d.get("status")
    if status not in ("Новая","Подтверждена","Отменена","Посетила"):
        raise HTTPException(400, "Недопустимый статус")
    with db() as con:
        cur = con.execute("UPDATE bookings SET status=? WHERE id=?", (status,booking_id))
        if cur.rowcount == 0: raise HTTPException(404, "Запись не найдена")
    return {"ok":True}

@app.delete("/api/admin/sessions/{session_id}")
def admin_delete_session(session_id: int, _: str = Depends(require_admin)):
    with db() as con:
        con.execute("UPDATE sessions SET active=0 WHERE id=?", (session_id,))
    return {"ok":True}
