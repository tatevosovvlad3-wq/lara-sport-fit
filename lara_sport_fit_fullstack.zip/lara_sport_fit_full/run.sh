#!/usr/bin/env sh
set -a
[ -f .env ] && . ./.env
set +a
uvicorn app:app --host 0.0.0.0 --port 8000
